def developer1method():
    print('Shokhrukh')
    print('Davlatmamadov')
    print('shodavlat21@gmail.com')
    print('Freshman')
    print('19')
    print('21.04.2003')
    print('Computer Science')
    print('Tajikistan')
def developer2method():
    print('Name: Atai')
    print('Surname: Cholponkulov')
    print('Email: ataicholponkulov@gmail.com')
    print('Cohort: Senior')
    print('Age: 22')
    print('Gender: male')
    print('Birthdate: 09.12.1999')
    print('Speciality: Computer Science')
    print('Country of Origin: Kyrgyzstan')
def developer3method():
    pass