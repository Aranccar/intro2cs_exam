This repo was created for intro2cs exam.

Please meet our team!

Shokhrukh Davlatmamadov
Uran Dzhundubaev
Atai Cholponkulov